package com.example.modul_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
